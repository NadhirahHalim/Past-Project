// A java program to find minimum possible time by the car chassis to complete
import java.io.*;
import java.util.Scanner;
import java.util.Random;

public class Main
{
    static int NUM_LINE = 2;    //PO = 1
    
    // Utility function to find minimum of two numbers
    static int min(int a, int b)
    {
        return (a < b ? a : b); //PO = 2
    }
    
    static int carAssembly(int a[][], int t[][], int e[], int x[], int n)
    {
        int counter = 0;
        counter += 2;
        int T1[] = new int [n]; // PO = 2
        counter += 2;
        int T2[] = new int[n] ; // PO = 2
        int i;
     
        // time taken to leave first station in line 1
        counter += 5;
        T1[0] = e[0] + a[0][0]; //PO = 5
        
        // time taken to leave first station in line 2
        counter += 5;
        T2[0] = e[1] + a[1][0]; //PO = 5
    
        // Fill tables T1[] and T2[] using
        // the above given recursive relations
        
        for (i = 1; i < n; i++) //PO = 1 + (n) + 2(n-1) = 3n - 1 = 2
        {
            counter = counter + 16;
            T1[i] = min(T1[i - 1] + a[0][i], T2[i - 1] + t[1][i] + a[0][i]); //12(n-1) = 12 + 2
            counter = counter + 14;
            T2[i] = min(T2[i - 1] + a[1][i], T1[i - 1] + t[0][i] + a[1][i]); //12(n-1) = 12 + 2
        }
        // Consider exit times and return minimum
        // Counter for min function and the return function
        counter = counter + 12;
        count(counter);
        return min(T1[n-1] + x[0], T2[n-1] + x[1]); // PO = 2+1+1+2+1+1+2+1+1 = 12
    }
    
    //Counter code
    static void count(int counter)
    {
        int c = 0;
        c = counter;
        c = c + 1;
        System.out.println("Total counter is: " + c);
    }
    
    // Driver code
    public static void main (String[] args)
    {
        int al = 2;
        Scanner i = new Scanner(System.in);
        Random rand = new Random();
        System.out.print("Number of stations: ");
        int n = i.nextInt();
        int a[][] = new int [al][n];
        int t[][] = new int [al][n];
        t[0][0]=0;
        t[1][0]=0;
        int e[] = new int[al];
        int x[] = new int[al];
        
        System.out.println("");
        //Time taken for station to change station within same assembly line
        System.out.println("Random time taken for car chassis to get into line: ");
        for(int j=0; j<al; j++){
            for(int k=0; k<n; k++){
                a[j][k]= rand.nextInt(20);
                if (j==0)
                    System.out.println("Line 1 station "+ (k+1) + " : " + a[j][k]);
                else
                    System.out.println("Line 2 station "+ (k+1) + " : " + a[j][k]);
            }
        }
        
        System.out.println("");
        //Time for each station to change assembly line
        System.out.println("Random time taken for car chassis to change assembly line respectively: ");
        for(int j=0; j<al; j++){
            for(int k=0; k<n; k++){
                if((j==0) && (k==0) || (j==1) && (k==0)){
                    if(j==0)
                    System.out.println("Assembly line 1 to line 2: " + t[j][k]); 
                    else
                    System.out.println("Assembly line 2 to line 1: " + t[j][k]);
                }
                else if (j==0){
                    t[j][k] = rand.nextInt(20);
                    System.out.println("Assembly line 1 to line 2: " + t[j][k]); 
                }
                else{
                    t[j][k] = rand.nextInt(20);
                    System.out.println("Assembly line 2 to line 1: " + t[j][k]); 
                }
            }
        }
        
        System.out.println("");
        //Time to enter station
        System.out.println("Time taken for car chassis to enter assembly line: ");
        for(int j=0; j<al; j++){
                    e[j] = rand.nextInt(20);
                    if(j==0)
                        System.out.println("Line 1: " + e[j]); 
                    else
                        System.out.println("Line 2: " + e[j]); 
        }
        
        System.out.println("");
        //Time to exit station
        System.out.println("Time taken for car chassis to exit assembly line: ");
        for(int j=0; j<al; j++){
                    x[j] = rand.nextInt(20);
                    if(j==0)
                        System.out.println("Line 1: " + x[j]); 
                    else
                        System.out.println("Line 2: " + x[j]); 
        }
        System.out.println("");
        int w = (carAssembly(a, t, e, x, n));   
        System.out.println("The minimum time taken is: " + w);
    }
}