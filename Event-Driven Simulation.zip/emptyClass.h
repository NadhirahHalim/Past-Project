#include <cassert> 
#include<iostream>
#include<iomanip>
using namespace std;

template<class Type4>
struct nodeType4
{
	Type4 info;
	nodeType4<Type4> *link;
};

template <class Type4>
class emptyClass
{
	private:
		int count;
		nodeType4<Type4> *first;
		nodeType4<Type4> *last;
	public:
		void initializeList(); 
		bool isEmptyList() const;
		void print() const;
		int length() const;
		void destroyList();
		int front() const; 
		int back() const; 
		void insert(Type4& newItem); 
		void deleteNode(const int& deleteItem); 
		void deleteQueue();
		void search(const int& searchItem);
		emptyClass();
		~emptyClass();
	
};


template<class Type4>
emptyClass<Type4> :: emptyClass()
{
	first=NULL;
	last=NULL;
	count=0;
}
	
template<class Type4>
emptyClass<Type4> :: ~emptyClass()
{
	destroyList();
}

template<class Type4>
void emptyClass<Type4> :: initializeList()
{
	destroyList();
}

template<class Type4>
bool emptyClass<Type4> :: isEmptyList() const
{
	return(first==NULL);
}

template<class Type4>
void emptyClass<Type4> :: print() const
{
nodeType4<Type4> *current;
	current=first;
	cout<<left;
	cout<<"\n";
	cout<<setw(20)<<"Begin memory"<<setw(20)<<"End memory"<<"Size Memory"<<endl<<endl;
	while(current!= NULL)
	{
		cout<<setw(20)<<current->info.beginmemory<<setw(20)<<current->info.endmemory<<current->info.sizememory<<endl;
		current=current->link;
	}
}

template<class Type4>
int emptyClass<Type4> :: length() const
{
	return count;
}

template<class Type4>
void emptyClass<Type4> :: destroyList()
{
	nodeType4<Type4> *temp;
	
	while(first!=NULL)
	{
		temp=first;
		first=first->link;
		delete temp;
	}
	last=NULL;
	count=0;
}

template<class Type4>
int emptyClass<Type4> :: front() const
{
	assert(first != NULL);
	return first->info;
}
	
template<class Type4>
int emptyClass<Type4> :: back() const
{
	assert(last !=NULL);
	return last->info;
}

template<class Type4>
void emptyClass<Type4> :: insert(Type4& newItem)
{	
	
	nodeType4<Type4> *current;
	nodeType4<Type4> *trailCurrent;
	nodeType4<Type4> *temp;
	
	
	temp= new nodeType4<Type4>;
	temp->info = newItem;
	temp->link =NULL;
	
	if(first==NULL){
		first= temp;
		last=temp;
	}
	
	else
	{
		current=first;
	
		
		while(current!= NULL)
		{
			if( newItem.beginmemory == current->info.endmemory )
			{
				current->info.endmemory = newItem.endmemory;
				current->info.sizememory +=newItem.sizememory;
			}
		
			
			if( current->info.beginmemory == newItem.endmemory )
			{
				current->info.beginmemory = newItem.beginmemory;
				current->info.sizememory +=newItem.sizememory;
				
			}
			else
			{
				
				current->info.beginmemory =current->info.beginmemory ;
				current->info.endmemory = current->info.endmemory  ;
				current->info.sizememory ;
				
			}
			
			trailCurrent=current;
			current=current->link;
				
		}
		
		if(current==NULL)
			{
			last=temp;
			}
							
	}
	//print();
}


template<class Type4>
void emptyClass<Type4> :: deleteNode(const int& deleteItem)
{
	nodeType4<Type4> *current;
	nodeType4<Type4> *trailCurrent;
	
	bool found;
	
	if(first == NULL)
		cout<<"Cannot delete from an empty list."<<endl;
	else
	{
		if(first->info == deleteItem)
		{
			current=first;
			first= first->link;
			count--;
			if(first==NULL)
				last=NULL;
			delete current;
		}
		else
		{
			found = false;
			trailCurrent=first;
			current=first->link;
			
			while(current!=NULL&& !found)
			{
				if(current->info !=deleteItem)
				{
					trailCurrent = current;
					current=current->link;
				}
				else
					found=true;
			}
			
			if(found)
			{
				trailCurrent->link=current->link;
				count--;
				
				if(last ==current)
					last=trailCurrent;
				delete current;
			}
			else
				cout<<"Item to be deleted is not in the list."<<endl;
		}
	}
}

template<class Type4>
void emptyClass<Type4> :: deleteQueue()
{
	nodeType4<Type4> *temp;
	if(!isEmptyList())
	{
		temp=first;
		first=first->link;
		delete temp;
		if(first==NULL)
		last=NULL;
	}
	else
	cout<<"Cannot delete from an empty list"<<endl;
}

template <class Type4>
void emptyClass<Type4>::search(const int& searchItem){
	nodeType4<Type4> *current;
	nodeType4<Type4> *trailcurrent;
	bool found=false;
	current=first;
	
	while(current != NULL && !found){
		if((current->info.begin-trailcurrent->info.end)>=searchItem){
			found=true;
		}
		else{
			trailcurrent=current;
			current=current->link;
		}
	}
		
	if(found==true){
		insert(searchItem);
	}
	else{
		return -1;
	}
}
